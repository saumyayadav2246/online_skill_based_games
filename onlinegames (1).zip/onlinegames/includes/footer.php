<script src="/onlinegames/assets/js/bootstrap.bundle.min.js"></script>
</body>
</html>